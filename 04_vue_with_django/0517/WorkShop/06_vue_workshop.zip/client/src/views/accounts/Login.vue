<template>
  <div></div>
</template>

<script>
// import axios from 'axios'

// const SERVER_URL = process.env.VUE_APP_SERVER_URL

export default {
  name: 'Login',
  data: function () {
    return {}
  },
  methods: {
    login: function () {
      
    }
  }
}
</script>
